"""اختبارات بوابات التشغيل: مطاردة، نافذة تنفيذ، جودة بيانات، dedupe تيليجرام."""

import os
import sys
import tempfile
import unittest
from datetime import datetime
from unittest.mock import patch
from zoneinfo import ZoneInfo

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from cheap_options_screener_v3 import (  # noqa: E402
    assess_option_price_quality,
    compute_entry_level,
    entry_is_chased,
    exec_block_rec_note,
    find_nearest_expiry,
    gap_direction_conflict,
    grade_wait_setup,
    inverse_recommendation_ceiling,
    is_exec_window,
    is_mega_cap_ticker,
    is_regular_session_over,
    next_friday_date,
    pin_priority_tickers,
    premium_is_chased,
    previous_trading_day,
    row_passes_save_filters,
    score_stock,
    spy_alignment_ok,
    spy_flip_blocked,
    tp1_already_reached,
    _pick_best_strike,
)
from data_quality import classify_data_quality  # noqa: E402
from outcome_tracker import (  # noqa: E402
    _row_is_hot_wait,
    add_new_recommendations,
    apply_data_quality,
    apply_path_metrics,
    compute_path_metrics,
    enrich_market_exit_premiums,
    expiry_reached,
    parse_telegram_alert_key,
    resolve_first_touch,
    sync_telegram_sent_flags,
)
from telegram_notify import (  # noqa: E402
    alert_key,
    is_active_watch,
    is_hot_wait_row,
    load_sent,
    prune_sent,
    save_sent,
    select_buy_rows,
    select_hot_wait_rows,
    spy_direction_already_sent,
    telegram_skip_reason,
    wait_hot_direction_conflict,
)

ET = ZoneInfo("America/New_York")


class TestPremiumQuality(unittest.TestCase):
    def test_market_mid_ok(self):
        q = assess_option_price_quality(
            premium=2.50, bs_fair=2.40, iv_raw=0.35,
            bid=2.40, ask=2.60, spread_pct=0.08,
        )
        self.assertEqual(q["premium_quality"], "market")
        self.assertTrue(q["premium_ok_for_buy"])
        self.assertTrue(q["show_bs_scenarios"])

    def test_market_without_bid_ask_still_buyable(self):
        # ثغرة سابقة: بدون opt_bid/ask كانت الجودة estimate وتسد BUY
        q = assess_option_price_quality(
            premium=2.34, bs_fair=2.20, iv_raw=0.1094,
            bid=None, ask=None, spread_pct=0.0043, synthetic_quote=False,
        )
        self.assertEqual(q["premium_quality"], "market")
        self.assertTrue(q["premium_ok_for_buy"])

    def test_iv_missing_market_mid_still_buyable(self):
        q = assess_option_price_quality(
            premium=2.50, bs_fair=2.45, iv_raw=0.0,
            bid=2.40, ask=2.60, spread_pct=0.08,
        )
        self.assertEqual(q["premium_quality"], "estimate")
        self.assertTrue(q["premium_ok_for_buy"])
        self.assertFalse(q["show_bs_scenarios"])

    def test_bs_near_zero_vs_market_unreliable(self):
        q = assess_option_price_quality(
            premium=2.40, bs_fair=0.01, iv_raw=0.016,
            bid=2.30, ask=2.50, spread_pct=0.08,
        )
        self.assertEqual(q["premium_quality"], "unreliable")
        self.assertFalse(q["premium_ok_for_buy"])
        self.assertFalse(q["show_bs_scenarios"])

    def test_synthetic_last_is_estimate(self):
        q = assess_option_price_quality(
            premium=1.80, bs_fair=1.70, iv_raw=0.40,
            bid=1.75, ask=1.85, synthetic_quote=True,
        )
        self.assertEqual(q["premium_quality"], "estimate")
        self.assertFalse(q["premium_ok_for_buy"])

    def test_wide_divergence_unreliable(self):
        q = assess_option_price_quality(
            premium=2.00, bs_fair=0.80, iv_raw=0.30,
            bid=1.90, ask=2.10, spread_pct=0.09,
        )
        self.assertEqual(q["premium_quality"], "unreliable")
        self.assertFalse(q["show_bs_scenarios"])


class TestBuyRequiresTrend(unittest.TestCase):
    def test_entry_hit_without_trend_is_wait_not_buy(self):
        """ثغرة SPCH: buy_ready + Entry بدون اتجاه كان يعطي BUY."""
        import os
        os.environ["IGNORE_EXEC_WINDOW"] = "1"
        from cheap_options_screener_v3 import compute_trade_plan

        r = {
            "Ticker": "SPCH",
            "price_num": 8.20,
            "Price": 8.20,
            "strike": 8.0,
            "iv": 0.80,
            "premium": 1.05,
            "oi": 878,
            "opt_vol": 600,
            "spread_pct": 0.09,
            "dte_num": 4,
            "direction": "CALL",
            "Score": 20,
            "spy_regime": "BULL",
            "RVOL": 1.5,
            "atr_pct": 6.0,
            "is_0dte": False,
            "opt_bid": 1.00,
            "opt_ask": 1.10,
            "synthetic_quote": False,
            "pm_high": 8.10,
            "pm_low": 7.80,
        }
        tech = {
            "atr14": 0.45,
            "trend": "MIXED",  # conf ~ سيكون <75 → mixed_ok False
            "above_ema20": False,
            "above_ema50": False,
            "above_vwap": True,
            "rsi": 35,
            "yesterday_high": 8.30,
            "yesterday_low": 7.90,
        }
        plan = compute_trade_plan(r, tech)
        # حتى لو السعر فوق Entry: بدون اتجاه مؤكد → لا BUY
        self.assertNotEqual(plan["recommendation"], "BUY")
        self.assertNotIn("Entry تحقق + شروط BUY مكتملة", plan.get("rec_note") or "")


class TestExpiryFriday(unittest.TestCase):
    def test_next_friday_skips_today_when_friday(self):
        fri = __import__("datetime").date(2026, 8, 7)  # Friday
        self.assertEqual(next_friday_date(fri).isoformat(), "2026-08-14")

    def test_on_friday_picks_next_friday_not_0dte(self):
        fri = __import__("datetime").date(2026, 8, 7)
        exps = ["2026-08-07", "2026-08-14", "2026-08-21"]
        exp, dte = find_nearest_expiry(exps, ticker="NVDA", today=fri)
        self.assertEqual(exp, "2026-08-14")
        self.assertEqual(dte, 7)

    def test_thursday_picks_tomorrow_friday(self):
        thu = __import__("datetime").date(2026, 8, 6)
        exps = ["2026-08-07", "2026-08-14"]
        exp, dte = find_nearest_expiry(exps, ticker="SPY", today=thu)
        self.assertEqual(exp, "2026-08-07")
        self.assertEqual(dte, 1)


class TestInverseGate(unittest.TestCase):
    def test_sqqq_call_in_bull_is_avoid(self):
        ceiling, note = inverse_recommendation_ceiling(True, "BULL", "SQQQ")
        self.assertEqual(ceiling, "AVOID")
        self.assertIn("صاعد", note)

    def test_sqqq_put_in_bull_is_wait_not_buy(self):
        ceiling, note = inverse_recommendation_ceiling(False, "BULL", "SQQQ")
        self.assertEqual(ceiling, "WAIT")
        self.assertNotEqual(ceiling, "BUY")

    def test_sqqq_neutral_no_buy(self):
        ceiling, _ = inverse_recommendation_ceiling(True, "NEUTRAL", "SQQQ")
        self.assertEqual(ceiling, "WAIT")

    def test_normal_stock_unchanged(self):
        ceiling, note = inverse_recommendation_ceiling(True, "BULL", "NVDA")
        self.assertEqual(ceiling, "BUY")
        self.assertEqual(note, "")


class TestMegaCapFinalOrder(unittest.TestCase):
    """أمر أخير: فك SPY عن الكبار + OTM رخيص ≤$3."""

    def test_mega_cap_call_ok_when_spy_bear(self):
        ok, note = spy_alignment_ok(True, "BEAR", "AMZN")
        self.assertTrue(ok)
        self.assertEqual(note, "")
        self.assertTrue(is_mega_cap_ticker("TSLA"))

    def test_non_mega_call_still_blocked_when_spy_bear(self):
        ok, note = spy_alignment_ok(True, "BEAR", "SMCI")
        self.assertFalse(ok)
        self.assertIn("SPY هابط", note)

    def test_mega_put_ok_when_spy_bull(self):
        ok, _ = spy_alignment_ok(False, "BULL", "AAPL")
        self.assertTrue(ok)

    def test_amzn_picks_cheap_otm_not_expensive_atm(self):
        # ATM ~$4.2 خارج/غالي · OTM ~$1.55 قرب الهدف
        chain = _opt_chain([
            (260.0, 4.20),
            (262.5, 3.40),
            (265.0, 2.10),
            (268.0, 1.55),
            (272.0, 1.05),
            (280.0, 0.40),  # تحت $1 — يُستبعد
        ])
        leg = _pick_best_strike(chain, 262.66, True, "AMZN")
        self.assertIsNotNone(leg)
        self.assertLessEqual(leg["premium"], 3.0)
        self.assertGreaterEqual(leg["premium"], 1.0)
        self.assertGreater(leg["strike"], 262.66)  # OTM CALL
        # يفضّل قرب $1.50
        self.assertLessEqual(abs(leg["premium"] - 1.50), 0.70)

    def test_msft_not_rejected_for_stock_price_alone(self):
        row = {
            "Ticker": "MSFT",
            "price_num": 533.50,
            "premium": 1.60,
            "spread_pct": 0.05,
            "oi": 2000,
            "opt_vol": 800,
            "strike": 540.0,
            "dte_num": 5,
            "tp1_stock": 545.0,
            "tp2_stock": 550.0,
            "tp3_stock": 555.0,
            "stop_stock": 528.0,
            "entry_stock": 535.0,
        }
        self.assertTrue(row_passes_save_filters(row))

    def test_priority_pins_mega_caps(self):
        df = pd.DataFrame([
            {"Ticker": "ZZZ", "_FastScore": 99},
            {"Ticker": "AMZN", "_FastScore": 1},
            {"Ticker": "SPY", "_FastScore": 2},
            {"Ticker": "AAA", "_FastScore": 98},
        ])
        pinned = pin_priority_tickers(df)
        tickers = pinned["Ticker"].astype(str).str.upper().tolist()
        self.assertEqual(tickers[0], "SPY")
        self.assertIn("AMZN", tickers[:5])


class TestWaitGrade(unittest.TestCase):
    def test_mild_chase_can_be_hot(self):
        # مثل NVDA/TQQQ هذا الأسبوع: مطاردة بسيطة مع مجال لـ TP2
        g = grade_wait_setup(
            conf=76, liquid_ok=True, prem_ok=True, align_ok=True, exec_ok=True,
            trend_ok=True, mixed_ok=False, plan_valid=True, chased=True,
            dte=3, is_0dte=False, live_rr=0.5, tp1_rr=2.0,
            price=211.85, entry=209.43, stop=207.5, tp2=218.7, tp3=226.0,
            is_call=True, atr_pct=2.5, score=22, rvol=2.2,
        )
        self.assertGreaterEqual(g["setup_pct"], 75)
        self.assertIn(g["wait_tier"], ("HOT", "FIRE"))

    def test_cold_when_misaligned(self):
        g = grade_wait_setup(
            conf=40, liquid_ok=False, prem_ok=False, align_ok=False, exec_ok=False,
            trend_ok=False, mixed_ok=False, plan_valid=False, chased=False,
            dte=0, is_0dte=True, live_rr=0.2, tp1_rr=0.5,
            price=100, entry=100, stop=99, tp2=102, tp3=104,
            is_call=True, atr_pct=1.0, score=5, rvol=0.5,
        )
        self.assertLess(g["setup_pct"], 55)
        self.assertEqual(g["wait_tier"], "COLD")


class TestChase(unittest.TestCase):
    def test_call_not_chased_at_entry(self):
        self.assertFalse(entry_is_chased(100.0, 100.0, True))

    def test_call_chased_beyond_limit(self):
        self.assertTrue(entry_is_chased(100.9, 100.0, True))  # +0.9% > 0.8%

    def test_call_within_tolerance(self):
        self.assertFalse(entry_is_chased(100.5, 100.0, True))  # +0.5% < 0.8%

    def test_put_chased_below_entry(self):
        self.assertTrue(entry_is_chased(99.1, 100.0, False))  # -0.9% > 0.8%


class TestExecWindow(unittest.TestCase):
    def setUp(self):
        os.environ.pop("IGNORE_EXEC_WINDOW", None)

    def test_before_945_closed(self):
        self.assertFalse(is_exec_window(datetime(2026, 8, 3, 9, 44, tzinfo=ET)))

    def test_at_945_open(self):
        self.assertTrue(is_exec_window(datetime(2026, 8, 3, 9, 45, tzinfo=ET)))

    def test_at_close_closed(self):
        self.assertFalse(is_exec_window(datetime(2026, 8, 3, 16, 0, tzinfo=ET)))

    def test_weekend_closed(self):
        self.assertFalse(is_exec_window(datetime(2026, 8, 1, 12, 0, tzinfo=ET)))

    def test_ignore_env(self):
        os.environ["IGNORE_EXEC_WINDOW"] = "1"
        try:
            self.assertTrue(is_exec_window(datetime(2026, 8, 1, 12, 0, tzinfo=ET)))
        finally:
            os.environ.pop("IGNORE_EXEC_WINDOW", None)

    def test_after_close_is_session_over(self):
        self.assertTrue(is_regular_session_over(datetime(2026, 8, 3, 16, 0, tzinfo=ET)))
        self.assertFalse(is_regular_session_over(datetime(2026, 8, 3, 15, 59, tzinfo=ET)))
        self.assertTrue(is_regular_session_over(datetime(2026, 8, 1, 12, 0, tzinfo=ET)))

    def test_after_close_note_not_945(self):
        note = exec_block_rec_note(datetime(2026, 8, 3, 16, 5, tzinfo=ET))
        self.assertIn("السوق مغلق", note)
        self.assertNotIn("9:45", note)

    def test_before_945_note_keeps_window(self):
        note = exec_block_rec_note(datetime(2026, 8, 3, 9, 40, tzinfo=ET))
        self.assertIn("9:45", note)
        self.assertNotIn("السوق مغلق", note)


class TestExpiryReached(unittest.TestCase):
    def setUp(self):
        os.environ.pop("EOD_RUN", None)

    def tearDown(self):
        os.environ.pop("EOD_RUN", None)

    def test_intraday_friday_stays_open(self):
        d = datetime(2026, 8, 21).date()
        self.assertFalse(expiry_reached(d, d, eod=False))

    def test_eod_friday_closes(self):
        d = datetime(2026, 8, 21).date()
        self.assertTrue(expiry_reached(d, d, eod=True))

    def test_monday_after_friday_expires_without_eod(self):
        friday = datetime(2026, 8, 21).date()
        monday = datetime(2026, 8, 24).date()
        self.assertTrue(expiry_reached(monday, friday, eod=False))


class TestDataQuality(unittest.TestCase):
    def test_open(self):
        q, _ = classify_data_quality({"status": "open"})
        self.assertEqual(q, "open")

    def test_no_entry(self):
        q, _ = classify_data_quality({
            "status": "tp1_hit", "entry_hit": False,
            "premium": 1.5, "strike": 100, "exit_premium_source": "market",
            "option_pnl_pct": 10,
        })
        self.assertEqual(q, "unreliable")

    def test_estimate_partial(self):
        q, _ = classify_data_quality({
            "status": "tp1_hit", "entry_hit": True,
            "premium": 1.5, "strike": 100, "exit_premium_source": "estimate",
            "option_pnl_pct": 5,
        })
        self.assertEqual(q, "partial")

    def test_stop_with_option_profit_unreliable(self):
        q, note = classify_data_quality({
            "status": "stop_hit", "entry_hit": True,
            "premium": 1.5, "strike": 100, "exit_premium_source": "market",
            "option_pnl_pct": 40,
        })
        self.assertEqual(q, "unreliable")
        self.assertIn("Stop", note)

    def test_reliable_market(self):
        q, _ = classify_data_quality({
            "status": "tp1_hit", "entry_hit": True,
            "premium": 1.5, "strike": 100, "exit_premium_source": "market",
            "option_pnl_pct": 20,
        })
        self.assertEqual(q, "reliable")

    def test_reliable_theta(self):
        q, _ = classify_data_quality({
            "status": "tp1_hit", "entry_hit": True,
            "premium": 1.5, "strike": 100, "exit_premium_source": "theta",
            "option_pnl_pct": 20,
        })
        self.assertEqual(q, "reliable")

    def test_tp_estimate_big_loss_partial(self):
        q, _ = classify_data_quality({
            "status": "tp1_hit", "entry_hit": True,
            "premium": 2.0, "strike": 50, "exit_premium_source": "estimate",
            "option_pnl_pct": -55,
        })
        self.assertEqual(q, "partial")


class TestPreexistingLevels(unittest.TestCase):
    def _bar(self, o, h, l, c, day="2026-08-05"):
        return pd.DataFrame(
            {"Open": [o], "High": [h], "Low": [l], "Close": [c]},
            index=pd.to_datetime([day]),
        )

    def test_skips_tp_when_open_already_above_target(self):
        # مثل AMZN: افتتاح 281 فوق TP1 275 مع لمس Entry 271 في نفس اليوم
        post = self._bar(281.59, 282.79, 270.74, 272.65)
        touch = resolve_first_touch(
            post, True, stop=269.08, tp1=275.15, tp2=281.07, tp3=287.2, entry=271.61,
        )
        self.assertIsNone(touch)

    def test_allows_tp_when_open_below_target(self):
        post = self._bar(272.0, 276.0, 271.0, 275.5)
        touch = resolve_first_touch(
            post, True, stop=269.08, tp1=275.15, tp2=281.07, tp3=287.2, entry=271.61,
        )
        self.assertIsNotNone(touch)
        self.assertEqual(touch[0], "tp1_hit")

    def test_skips_stop_when_open_already_through_stop(self):
        # CALL: افتتاح تحت Stop ثم ارتد ولمس Entry — لا Stop نظيف
        post = self._bar(268.50, 272.50, 268.00, 271.80)
        touch = resolve_first_touch(
            post, True, stop=269.08, tp1=275.15, tp2=281.07, tp3=287.2, entry=271.61,
        )
        self.assertIsNone(touch)

    def test_allows_stop_when_open_above_stop(self):
        # افتتاح فوق Stop ثم كسره — Stop صالح
        post = self._bar(272.0, 273.0, 268.5, 269.0)
        touch = resolve_first_touch(
            post, True, stop=269.08, tp1=275.15, tp2=281.07, tp3=287.2, entry=271.61,
        )
        self.assertIsNotNone(touch)
        self.assertEqual(touch[0], "stop_hit")

    def test_rec_day_ignores_high_without_close_confirm(self):
        # مثل NVDA: قمة لمست TP1 لكن الإغلاق تحت الهدف يوم التوصية
        post = self._bar(221.53, 223.63, 217.27, 218.92, day="2026-08-06")
        touch = resolve_first_touch(
            post, True, stop=215.24, tp1=222.22, tp2=226.0, tp3=230.0, entry=217.90,
            rec_date="2026-08-06", price_at_rec=217.90,
        )
        self.assertIsNone(touch)

    def test_rec_day_tp_when_close_confirms(self):
        post = self._bar(218.0, 223.5, 217.5, 222.50, day="2026-08-06")
        touch = resolve_first_touch(
            post, True, stop=215.24, tp1=222.22, tp2=226.0, tp3=230.0, entry=217.90,
            rec_date="2026-08-06", price_at_rec=217.90,
        )
        self.assertIsNotNone(touch)
        self.assertEqual(touch[0], "tp1_hit")

    def test_after_rec_day_high_still_counts(self):
        # بعد يوم التوصية: High يكفي حتى لو الإغلاق تحت الهدف
        post = self._bar(220.0, 223.5, 219.0, 220.5, day="2026-08-07")
        touch = resolve_first_touch(
            post, True, stop=215.24, tp1=222.22, tp2=226.0, tp3=230.0, entry=217.90,
            rec_date="2026-08-06", price_at_rec=217.90,
        )
        self.assertIsNotNone(touch)
        self.assertEqual(touch[0], "tp1_hit")

    def test_skips_tp_already_at_price_at_rec(self):
        post = self._bar(223.0, 224.0, 222.5, 223.2, day="2026-08-06")
        touch = resolve_first_touch(
            post, True, stop=215.24, tp1=222.22, tp2=226.0, tp3=230.0, entry=217.90,
            rec_date="2026-08-06", price_at_rec=222.50,
        )
        self.assertIsNone(touch)


class TestTelegramDedupe(unittest.TestCase):
    def test_alert_key_stable(self):
        row = {
            "Ticker": "SPY", "direction": "CALL 📈",
            "strike": 773.0, "expiry": "2026-08-07",
        }
        k1 = alert_key(row, day="2026-08-05")
        k2 = alert_key(row, day="2026-08-05")
        self.assertEqual(k1, k2)
        self.assertEqual(k1, "2026-08-05|SPY|CALL|773.00|2026-08-07")
        self.assertEqual(
            alert_key(row, day="2026-08-05", kind="WAIT_HOT"),
            "WAIT_HOT|2026-08-05|SPY|CALL|773.00|2026-08-07",
        )

    def test_select_hot_wait_rows(self):
        df = pd.DataFrame([
            {
                "Ticker": "NVDA", "recommendation": "WAIT", "direction": "CALL",
                "strike": 220, "expiry": "2026-08-14", "exec_window_ok": True,
                "wait_tier": "HOT", "setup_pct": 82, "chase_pct": 0.8, "tp2_rr_live": 1.4,
            },
            {
                "Ticker": "AMD", "recommendation": "WAIT", "direction": "CALL",
                "strike": 100, "expiry": "2026-08-14", "exec_window_ok": True,
                "wait_tier": "COLD", "setup_pct": 40,
            },
            {
                "Ticker": "SPY", "recommendation": "BUY", "direction": "CALL",
                "strike": 770, "expiry": "2026-08-14", "exec_window_ok": True,
                "wait_tier": "FIRE", "setup_pct": 95,
            },
        ])
        day = "2026-08-07"
        to_send, _, _ = select_hot_wait_rows(df, sent_keys=set(), day=day)
        tickers = [r.get("Ticker") for _, r in to_send]
        self.assertEqual(tickers, ["NVDA"])
        self.assertTrue(is_hot_wait_row(df.iloc[0]))
        self.assertTrue(is_active_watch(df.iloc[0]))
        self.assertFalse(is_hot_wait_row(df.iloc[1]))

    def test_select_skips_duplicates(self):
        df = pd.DataFrame([
            {
                "Ticker": "SPY", "recommendation": "BUY", "direction": "CALL",
                "strike": 773, "expiry": "2026-08-07", "exec_window_ok": True,
            },
            {
                "Ticker": "AMZN", "recommendation": "BUY", "direction": "CALL",
                "strike": 272.5, "expiry": "2026-08-07", "exec_window_ok": True,
            },
            {
                "Ticker": "X", "recommendation": "WAIT", "direction": "CALL",
                "strike": 1, "expiry": "2026-08-07", "exec_window_ok": True,
            },
        ])
        day = "2026-08-05"
        spy_key = alert_key(df.iloc[0], day=day)
        to_send, skipped, _ = select_buy_rows(
            df, sent_keys={spy_key}, force=False, day=day,
        )
        tickers = [r.get("Ticker") for _, r in to_send]
        self.assertEqual(tickers, ["AMZN"])
        self.assertEqual(len(skipped), 1)

    def test_select_skips_closed_window(self):
        df = pd.DataFrame([{
            "Ticker": "SPY", "recommendation": "BUY", "direction": "CALL",
            "strike": 773, "expiry": "2026-08-07", "exec_window_ok": False,
        }])
        to_send, _, skipped_w = select_buy_rows(df, sent_keys=set(), day="2026-08-05")
        self.assertEqual(len(to_send), 0)
        self.assertEqual(len(skipped_w), 1)

    def test_sent_file_roundtrip(self):
        # save_sent() prunes keys older than SENT_KEEP_DAYS vs today ET.
        # A fixed August date would start failing ~3 weeks later.
        day = datetime.now(ET).strftime("%Y-%m-%d")
        key = f"{day}|SPY|CALL|1.00|{day}"
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "telegram_sent.json")
            save_sent({"sent": {key: "t"}}, path)
            loaded = load_sent(path)
            self.assertIn(key, loaded["sent"])

    def test_prune_old_keys(self):
        sent = {
            "2026-01-01|A|CALL|1.00|2026-01-10": "old",
            "2026-08-05|B|CALL|1.00|2026-08-07": "new",
            "WAIT_HOT|2026-01-02|C|PUT|2.00|2026-01-10": "old_hot",
            "WAIT_HOT|2026-08-04|D|CALL|3.00|2026-08-07": "new_hot",
        }
        pruned = prune_sent(sent, keep_days=21, today="2026-08-05")
        self.assertNotIn("2026-01-01|A|CALL|1.00|2026-01-10", pruned)
        self.assertNotIn("WAIT_HOT|2026-01-02|C|PUT|2.00|2026-01-10", pruned)
        self.assertIn("2026-08-05|B|CALL|1.00|2026-08-07", pruned)
        self.assertIn("WAIT_HOT|2026-08-04|D|CALL|3.00|2026-08-07", pruned)

    def test_spy_one_card_per_direction(self):
        day = "2026-09-10"
        df = pd.DataFrame([
            {
                "Ticker": "SPY", "recommendation": "BUY", "direction": "PUT",
                "strike": 757, "expiry": "2026-09-11", "exec_window_ok": True,
                "tp1_rr_live": 1.6, "rec_note": "Entry تحقق",
            },
            {
                "Ticker": "SPY", "recommendation": "BUY", "direction": "PUT",
                "strike": 756, "expiry": "2026-09-11", "exec_window_ok": True,
                "tp1_rr_live": 1.6, "rec_note": "Entry تحقق",
            },
            {
                "Ticker": "SPY", "recommendation": "BUY", "direction": "CALL",
                "strike": 770, "expiry": "2026-09-11", "exec_window_ok": True,
                "tp1_rr_live": 1.6, "rec_note": "Entry تحقق",
            },
        ])
        to_send, skipped, _ = select_buy_rows(df, sent_keys=set(), day=day)
        strikes = [float(r.get("strike")) for _, r in to_send]
        self.assertEqual(strikes, [757.0, 770.0])
        self.assertEqual(len(skipped), 1)

    def test_spy_direction_blocks_other_strike_and_kind(self):
        day = "2026-09-10"
        sent = {"2026-09-10|SPY|PUT|757.00|2026-09-11"}
        self.assertTrue(spy_direction_already_sent(sent, day, "PUT"))
        df = pd.DataFrame([{
            "Ticker": "SPY", "recommendation": "WAIT", "direction": "PUT",
            "strike": 748, "expiry": "2026-09-11", "exec_window_ok": True,
            "wait_tier": "HOT", "setup_pct": 90, "tp1_rr_live": 1.6,
            "rec_note": "جاهز",
        }])
        to_send, skipped, _ = select_hot_wait_rows(df, sent_keys=sent, day=day)
        self.assertEqual(to_send, [])
        self.assertEqual(len(skipped), 1)

    def test_skip_weak_rr_rejected_and_closed(self):
        day = "2026-09-18"
        df = pd.DataFrame([
            {
                "Ticker": "SPY", "recommendation": "WAIT", "direction": "PUT",
                "strike": 754, "expiry": "2026-09-18", "exec_window_ok": True,
                "wait_tier": "FIRE", "setup_pct": 99, "tp1_rr_live": 0.7,
                "rec_note": "R:R الحي 1:0.7 ضعيف",
            },
            {
                "Ticker": "NVDA", "recommendation": "WAIT", "direction": "CALL",
                "strike": 215, "expiry": "2026-09-18", "exec_window_ok": True,
                "wait_tier": "HOT", "setup_pct": 79, "tp1_rr_live": 1.2,
                "rec_note": "CALL مرفوض — SPY هابط (فلتر اتجاه) — مراقبة فقط",
            },
            {
                "Ticker": "AMZN", "recommendation": "WAIT", "direction": "PUT",
                "strike": 248, "expiry": "2026-09-18", "exec_window_ok": True,
                "wait_tier": "HOT", "setup_pct": 82, "tp1_rr_live": 1.5,
                "rec_note": "السوق مغلق — لا تنفيذ بعد الإغلاق",
            },
            {
                "Ticker": "MSFT", "recommendation": "WAIT", "direction": "CALL",
                "strike": 500, "expiry": "2026-09-18", "exec_window_ok": True,
                "wait_tier": "HOT", "setup_pct": 80, "tp1_rr_live": 1.4,
                "rec_note": "جاهز لدخول يدوي",
            },
        ])
        self.assertEqual(telegram_skip_reason(df.iloc[0]), "weak_rr")
        self.assertEqual(telegram_skip_reason(df.iloc[1]), "align")
        self.assertEqual(telegram_skip_reason(df.iloc[2]), "closed")
        self.assertEqual(telegram_skip_reason(df.iloc[3]), "")
        to_send, _, skipped = select_hot_wait_rows(df, sent_keys=set(), day=day)
        tickers = [r.get("Ticker") for _, r in to_send]
        self.assertEqual(tickers, ["MSFT"])
        self.assertEqual(len(skipped), 3)


class TestTelegramOutcomeSync(unittest.TestCase):
    def test_parse_wait_hot_key(self):
        info = parse_telegram_alert_key("WAIT_HOT|2026-08-13|CRWV|PUT|110.00|2026-08-14")
        self.assertEqual(info["kind"], "WAIT_HOT")
        self.assertEqual(info["ticker"], "CRWV")
        self.assertEqual(info["direction"], "PUT")
        self.assertEqual(info["strike"], 110.0)
        self.assertEqual(info["expiry"], "2026-08-14")

    def test_sync_marks_and_adds_missing(self):
        with tempfile.TemporaryDirectory() as td:
            sent_path = os.path.join(td, "telegram_sent.json")
            # freeze prune clock — save_sent vs today ET would drop Aug-10 keys after 21d
            save_sent({
                "sent": {
                    "2026-08-10|AAA|CALL|100.00|2026-08-14": "2026-08-10T12:00:00Z",
                    "WAIT_HOT|2026-08-10|BBB|PUT|50.00|2026-08-14": "2026-08-10T13:00:00Z",
                }
            }, sent_path, today="2026-08-14")
            outcomes = pd.DataFrame([{
                "date": "2026-08-10",
                "ticker": "AAA",
                "direction": "CALL",
                "score": 10,
                "confidence": 60,
                "price_at_rec": 100,
                "entry_stock": 99,
                "stop_stock": 95,
                "tp1_stock": 105,
                "tp2_stock": 108,
                "tp3_stock": 110,
                "expiry": "2026-08-14",
                "premium": 1.2,
                "strike": 100,
                "rec_kind": "BUY",
                "entry_hit": False,
                "status": "open",
                "data_quality": "open",
            }])
            out = sync_telegram_sent_flags(outcomes, sent_path=sent_path, add_missing=True)
            aaa = out[out["ticker"] == "AAA"].iloc[0]
            self.assertTrue(bool(aaa["telegram_sent"]))
            self.assertEqual(aaa["telegram_kind"], "BUY")
            bbb = out[out["ticker"] == "BBB"]
            self.assertEqual(len(bbb), 1)
            self.assertTrue(bool(bbb.iloc[0]["telegram_sent"]))
            self.assertEqual(bbb.iloc[0]["telegram_kind"], "WAIT_HOT")
            self.assertIn("telegram_sent", str(bbb.iloc[0]["rec_note"]))

    def test_buy_kind_not_overwritten_by_wait_hot(self):
        with tempfile.TemporaryDirectory() as td:
            sent_path = os.path.join(td, "telegram_sent.json")
            save_sent({
                "sent": {
                    "2026-08-11|NVDA|CALL|217.50|2026-08-14": "2026-08-11T18:32:11Z",
                    "WAIT_HOT|2026-08-11|NVDA|CALL|217.50|2026-08-14": "2026-08-11T14:59:11Z",
                }
            }, sent_path, today="2026-08-14")
            outcomes = pd.DataFrame([{
                "date": "2026-08-11",
                "ticker": "NVDA",
                "direction": "CALL",
                "score": 21,
                "confidence": 88,
                "price_at_rec": 217.35,
                "entry_stock": 217.35,
                "stop_stock": 215.0,
                "tp1_stock": 222.0,
                "tp2_stock": 228.0,
                "tp3_stock": 236.0,
                "expiry": "2026-08-14",
                "premium": 2.74,
                "strike": 217.5,
                "rec_kind": "BUY",
                "entry_hit": True,
                "status": "open",
                "data_quality": "open",
                "telegram_kind": "",
            }])
            out = sync_telegram_sent_flags(outcomes, sent_path=sent_path, add_missing=False)
            row = out.iloc[0]
            self.assertTrue(bool(row["telegram_sent"]))
            self.assertEqual(row["telegram_kind"], "BUY")
            self.assertEqual(len(out), 1)


class TestOutcomeRecKindUpgrade(unittest.TestCase):
    def test_inverse_not_hot_wait(self):
        r = pd.Series({
            "Ticker": "SQQQ", "recommendation": "WAIT",
            "wait_tier": "FIRE", "setup_pct": 95,
        })
        self.assertFalse(_row_is_hot_wait(r))

    def test_wait_hot_upgrades_to_buy(self):
        with tempfile.TemporaryDirectory() as td:
            prev = os.getcwd()
            os.chdir(td)
            try:
                outcomes = pd.DataFrame([{
                    "date": "2099-01-01",
                    "ticker": "NVDA",
                    "direction": "CALL",
                    "score": 10,
                    "confidence": 60,
                    "price_at_rec": 180,
                    "entry_stock": 179.0,
                    "stop_stock": 175.0,
                    "tp1_stock": 185.0,
                    "tp2_stock": 188.0,
                    "tp3_stock": 192.0,
                    "expiry": "2099-01-10",
                    "premium": 1.5,
                    "strike": 180,
                    "iv": 0.4,
                    "dte_num": 5,
                    "rec_kind": "WAIT_HOT",
                    "entry_chased": False,
                    "setup_pct": 80,
                    "wait_tier": "HOT",
                    "scanned_at": "",
                    "status": "open",
                    "data_quality": "open",
                    "data_quality_note": "WAIT HOT",
                }])
                results = pd.DataFrame([{
                    "Ticker": "NVDA",
                    "recommendation": "BUY",
                    "direction": "CALL",
                    "Score": 22,
                    "confidence": 70,
                    "Price": 181,
                    "entry_stock": 179.5,
                    "stop_stock": 175,
                    "tp1_stock": 186,
                    "tp2_stock": 189,
                    "tp3_stock": 193,
                    "expiry": "2099-01-10",
                    "premium": 1.6,
                    "strike": 180,
                    "iv": 0.41,
                    "dte_num": 5,
                    "entry_chased": False,
                    "setup_pct": 88,
                    "wait_tier": "HOT",
                    "scanned_at": "2099-01-01 15:00 UTC",
                    "premium_quality": "market",
                    "premium_quality_note": "mid سوق (Bid/Ask)",
                    "bs_fair_price": 1.55,
                    "opt_bid": 1.50,
                    "opt_ask": 1.70,
                    "spread_pct": 0.05,
                    "oi": 2000,
                    "tp1_rr_live": 1.8,
                    "chase_pct": 0.2,
                    "spy_regime": "BULL",
                    "rec_note": "الاتجاه والزخم والسيولة مناسبة",
                }])
                results.to_csv("options_v3_results.csv", index=False)
                out = add_new_recommendations(outcomes)
                row = out[(out["ticker"] == "NVDA") & (out["status"] == "open")].iloc[0]
                self.assertEqual(str(row["rec_kind"]), "BUY")
                self.assertEqual(len(out[out["ticker"] == "NVDA"]), 1)
                self.assertEqual(str(row.get("premium_quality")), "market")
                self.assertEqual(float(row.get("tp1_rr_live")), 1.8)
                self.assertEqual(str(row.get("spy_regime")), "BULL")
                self.assertIn("الاتجاه", str(row.get("rec_note") or ""))
                self.assertEqual(float(row.get("opt_bid")), 1.5)
            finally:
                os.chdir(prev)


class TestKeptClosedQuality(unittest.TestCase):
    """صف مغلق موثوق لا يسقط عند 404 Yahoo."""

    def _closed(self, **kw):
        row = {
            "ticker": "SPY",
            "direction": "CALL",
            "status": "expired",
            "entry_hit": True,
            "date": "2026-08-13",
            "expiry": "2026-08-14",
            "exit_date": "2026-08-14",
            "premium": 2.45,
            "strike": 769.0,
            "exit_premium": 0.12,
            "exit_premium_source": "market",
            "option_pnl_pct": -95.1,
            "data_quality": "reliable",
            "data_quality_note": "دخول + سعر سوق/ذاتي + بدون تناقض",
            "entry_stock": 768.14,
            "exit_stock": 770.0,
            "stop_stock": 766.1,
            "tp1_stock": 771.82,
            "tp2_stock": 773.0,
            "tp3_stock": 0,
        }
        row.update(kw)
        return row

    def test_path_metrics_keep_market_when_hist_empty(self):
        row = self._closed()
        metrics = compute_path_metrics(row, pd.DataFrame(), today=datetime(2026, 8, 27).date())
        self.assertEqual(metrics["exit_premium_source"], "market")
        self.assertEqual(float(metrics["exit_premium"]), 0.12)

    def test_enrich_keeps_market_on_yahoo_miss(self):
        df = pd.DataFrame([self._closed()])
        with patch("outcome_tracker.market_option_close", return_value=None):
            out = enrich_market_exit_premiums(df, cache={})
        self.assertEqual(str(out.at[0, "exit_premium_source"]), "market")
        self.assertEqual(float(out.at[0, "exit_premium"]), 0.12)
        self.assertEqual(float(out.at[0, "option_pnl_pct"]), -95.1)

    def test_yahoo_miss_then_quality_stays_reliable(self):
        df = pd.DataFrame([self._closed()])
        with patch("outcome_tracker.market_option_close", return_value=None):
            df = enrich_market_exit_premiums(df, cache={})
        df = apply_data_quality(df)
        self.assertEqual(str(df.at[0, "data_quality"]), "reliable")

    def test_apply_path_metrics_does_not_blank_market(self):
        df = pd.DataFrame([self._closed()])
        apply_path_metrics(df, 0, {
            "exit_date": "2026-08-14",
            "exit_stock": 770.0,
            "exit_premium": None,
            "exit_premium_source": None,
            "days_to_entry": 0,
            "days_held": 1,
            "mfe_pct": 1.0,
            "mae_pct": -1.0,
            "hold_expiry_pct": None,
        })
        self.assertEqual(str(df.at[0, "exit_premium_source"]), "market")
        self.assertEqual(float(df.at[0, "exit_premium"]), 0.12)

    def test_stop_option_profit_still_unreliable(self):
        df = pd.DataFrame([self._closed(
            status="stop_hit", option_pnl_pct=40.0, data_quality="reliable",
        )])
        df = apply_data_quality(df)
        self.assertEqual(str(df.at[0, "data_quality"]), "unreliable")


def _opt_chain(pairs):
    rows = []
    for strike, prem in pairs:
        rows.append({
            "strike": strike,
            "bid": round(prem - 0.02, 2),
            "ask": round(prem + 0.02, 2),
            "lastPrice": prem,
            "impliedVolatility": 0.2,
            "openInterest": 5000,
            "volume": 2000,
        })
    return pd.DataFrame(rows)


class TestSpyStrikeDistance(unittest.TestCase):
    def test_prefers_near_atm_within_half_percent(self):
        # 756 ≈ 0.26% · 752 ≈ 0.79% (>0.5%) · 740 بعيد
        chain = _opt_chain([(740, 2.4), (752, 2.5), (756, 2.6)])
        leg = _pick_best_strike(chain, 758.0, False, "SPY")
        self.assertIsNotNone(leg)
        self.assertEqual(leg["strike"], 756.0)
        self.assertLessEqual(abs(leg["strike"] - 758.0) / 758.0, 0.005)

    def test_save_filter_drops_far_spy_strike(self):
        row = {
            "Ticker": "SPY",
            "price_num": 757.83,
            "premium": 2.47,
            "spread_pct": 0.02,
            "oi": 8000,
            "opt_vol": 1000,
            "strike": 740.0,
            "dte_num": 1,
            "tp1_stock": 752.0,
            "tp2_stock": 748.0,
            "tp3_stock": 744.0,
            "stop_stock": 761.0,
            "entry_stock": 759.0,
        }
        self.assertFalse(row_passes_save_filters(row))

    def test_first_seen_sticks_for_same_signal(self):
        import cheap_options_screener_v3 as screener
        prev = pd.DataFrame([{
            "Ticker": "SMCI", "recommendation": "WAIT",
            "scanned_at": "2026-09-25 13:01 UTC",
            "first_seen": "2026-09-25 13:01 UTC",
        }])
        later = pd.DataFrame([{
            "Ticker": "SMCI", "recommendation": "WAIT",
            "scanned_at": "2026-09-25 14:00 UTC",
        }])
        kept = screener.stamp_first_seen(later, prev)
        self.assertEqual(kept.iloc[0]["first_seen"], "2026-09-25 13:01 UTC")
        flipped = later.copy()
        flipped["recommendation"] = "BUY"
        fresh = screener.stamp_first_seen(flipped, prev)
        self.assertEqual(fresh.iloc[0]["first_seen"], "2026-09-25 14:00 UTC")

    def test_saved_csv_keeps_reject_reason(self):
        import cheap_options_screener_v3 as screener
        saved = {
            "Ticker": "SMCI", "Price": "$41.50", "price_num": 41.5, "premium": 1.8,
            "spread_pct": 0.04, "oi": 2000, "opt_vol": 500, "strike": 41.0,
            "dte_num": 5, "recommendation": "WAIT", "direction": "CALL",
            "tp1_stock": 44, "tp2_stock": 46, "tp3_stock": 48,
            "stop_stock": 40, "entry_stock": 41.2, "Score": 70,
        }
        pricey = dict(saved, Ticker="NVDA", Price="$180", price_num=180, premium=8.5,
                      strike=180, recommendation="BUY", Score=40)
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "options_v3_results.csv")
            log = os.path.join(folder, "options_rejected_log.csv")
            with patch.object(screener, "REJECT_LOG_PATH", log):
                screener.save_screen_results(pd.DataFrame([saved, pricey]), path)
            rows = pd.read_csv(path)
            nvda = rows[rows["Ticker"] == "NVDA"].iloc[0]
            self.assertEqual(nvda["recommendation"], "SKIP")
            self.assertIn("عقد", str(nvda["reject_reason"]))
            self.assertEqual(nvda["card_lane"], "rejected")
            logged = pd.read_csv(log)
            self.assertIn("عقد", str(logged.iloc[0]["reject_reason"]))

    def test_unaccepted_row_is_skip_not_buy(self):
        import pandas as pd
        from cheap_options_screener_v3 import frame_unaccepted
        saved = {
            "Ticker": "SMCI", "price_num": 41.5, "premium": 1.8,
            "spread_pct": 0.04, "oi": 2000, "opt_vol": 500, "strike": 41.0,
            "dte_num": 5, "recommendation": "WAIT",
            "tp1_stock": 44, "tp2_stock": 46, "tp3_stock": 48,
            "stop_stock": 40, "entry_stock": 41.2,
        }
        pricey = dict(saved, Ticker="NVDA", price_num=180, premium=8.5, strike=180,
                      recommendation="BUY")
        out = frame_unaccepted(pd.DataFrame([saved, pricey]), ["SMCI"])
        self.assertEqual(len(out), 1)
        self.assertEqual(out.iloc[0]["Ticker"], "NVDA")
        self.assertEqual(out.iloc[0]["recommendation"], "SKIP")
        self.assertIn("عقد", out.iloc[0]["reject_reason"])

    def test_reject_log_keeps_first_seen_same_day(self):
        import os
        import tempfile
        import pandas as pd
        from cheap_options_screener_v3 import append_options_reject_log
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "log.csv")
            first = pd.DataFrame([{
                "Ticker": "NVDA", "Price": "$180", "premium": 8.5, "strike": 180,
                "direction": "CALL", "Score": 40, "gap_pct": 2, "spy_regime": "BULL",
                "reject_reason": "العقد خارج النطاق", "scanned_at": "2026-09-25 13:00 UTC",
            }])
            later = first.copy()
            later["premium"] = 9.1
            later["scanned_at"] = "2026-09-25 14:00 UTC"
            self.assertEqual(append_options_reject_log(first, path), 1)
            self.assertEqual(append_options_reject_log(later, path), 0)
            rows = pd.read_csv(path)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows.iloc[0]["first_seen"], "2026-09-25 13:00 UTC")
            self.assertAlmostEqual(float(rows.iloc[0]["premium"]), 9.1)


class TestSpyFlipBlock(unittest.TestCase):
    def test_previous_trading_day_skips_weekend(self):
        self.assertEqual(previous_trading_day("2026-09-14"), "2026-09-11")

    def test_put_stop_blocks_call_same_day_and_next(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "outcomes.csv")
            pd.DataFrame([{
                "ticker": "SPY",
                "direction": "PUT",
                "status": "stop_hit",
                "exit_date": "2026-09-10",
            }]).to_csv(path, index=False)
            blocked, note = spy_flip_blocked(True, "SPY", today="2026-09-10", outcomes_path=path)
            self.assertTrue(blocked)
            self.assertIn("انقلاب ممنوع", note)
            blocked_next, _ = spy_flip_blocked(True, "SPY", today="2026-09-11", outcomes_path=path)
            self.assertTrue(blocked_next)
            blocked_later, _ = spy_flip_blocked(True, "SPY", today="2026-09-14", outcomes_path=path)
            self.assertFalse(blocked_later)
            same_side, _ = spy_flip_blocked(False, "SPY", today="2026-09-10", outcomes_path=path)
            self.assertFalse(same_side)

    def test_other_ticker_not_blocked(self):
        blocked, note = spy_flip_blocked(True, "NVDA", today="2026-09-11", outcomes_path="missing.csv")
        self.assertFalse(blocked)
        self.assertEqual(note, "")


class TestBreakEntry(unittest.TestCase):
    def test_call_entry_at_resistance_above(self):
        tech = {
            "resist1": 105.0, "resist2": 108.0,
            "support1": 98.0, "vwap": 101.0, "ema20": 100.5,
            "session_high": 103.0, "session_low": 99.0,
        }
        entry, note = compute_entry_level(
            100.0, True, pm_high=102.0, pm_low=99.0,
            yest_h=104.0, yest_l=97.0, atr=2.0, tech=tech,
        )
        self.assertGreater(entry, 100.0)
        self.assertIn("كسر", note)

    def test_put_entry_at_support_below(self):
        tech = {
            "resist1": 105.0, "support1": 97.0, "support2": 94.0,
            "vwap": 101.0, "ema20": 100.5,
            "session_high": 103.0, "session_low": 98.0,
        }
        entry, note = compute_entry_level(
            100.0, False, pm_high=102.0, pm_low=98.5,
            yest_h=104.0, yest_l=96.0, atr=2.0, tech=tech,
        )
        self.assertLess(entry, 100.0)
        self.assertIn("كسر", note)


class TestTp1AlreadyHit(unittest.TestCase):
    def test_call_session_high_touches_tp1(self):
        self.assertTrue(tp1_already_reached(110.0, 100.0, 109.5, True))
        self.assertFalse(tp1_already_reached(108.0, 100.0, 109.5, True))

    def test_put_session_low_touches_tp1(self):
        self.assertTrue(tp1_already_reached(110.0, 95.0, 96.0, False))
        self.assertFalse(tp1_already_reached(110.0, 97.0, 96.0, False))

    def test_buy_blocked_when_tp1_already_hit(self):
        os.environ["IGNORE_EXEC_WINDOW"] = "1"
        from cheap_options_screener_v3 import compute_trade_plan

        # PUT بعد كسر: السعر تحت Entry والكسر متحقّق، لكن أدنى الجلسة لمس TP1
        r = {
            "Ticker": "DRAM",
            "price_num": 45.1,
            "strike": 45.0,
            "iv": 0.55,
            "premium": 1.40,
            "oi": 2000,
            "opt_vol": 800,
            "spread_pct": 0.05,
            "dte_num": 3,
            "direction": "PUT",
            "Score": 22,
            "spy_regime": "BEAR",
            "RVOL": 2.0,
            "atr_pct": 4.0,
            "is_0dte": False,
            "opt_bid": 1.35,
            "opt_ask": 1.45,
            "synthetic_quote": False,
            "gap_pct": -2.0,
        }
        tech = {
            "atr14": 2.0,
            "trend": "BEARISH 🔴",
            "above_ema20": False,
            "above_ema50": False,
            "above_vwap": False,
            "rsi": 35,
            "resist1": 48.0,
            "support1": 45.5,  # كُسر للتو — السعر يثبت تحته
            "support2": 43.0,
            "support3": 41.5,
            "yesterday_high": 49.0,
            "yesterday_low": 46.0,
            "session_high": 48.5,
            "session_low": 41.0,  # لمس TP1 مسبقاً
        }
        plan = compute_trade_plan(r, tech)
        self.assertTrue(plan.get("tp1_already_hit"), plan)
        self.assertNotEqual(plan["recommendation"], "BUY")
        self.assertIn("TP1", plan.get("rec_note") or "")


class TestPremiumChase(unittest.TestCase):
    def test_spike_from_prev_is_chased(self):
        # 1.01 من 0.62 ≈ +63% — القياس يبقى؛ لا يسدّ BUY بعد الإلغاء
        self.assertTrue(premium_is_chased(1.01, prem_prev=0.62))
        self.assertFalse(premium_is_chased(0.80, prem_prev=0.70))

    def test_change_pct_flag(self):
        self.assertTrue(premium_is_chased(2.0, change_pct=55.0))
        self.assertFalse(premium_is_chased(2.0, change_pct=20.0, prem_prev=1.9))

    def test_premium_chase_no_longer_blocks_buy(self):
        """بعد إلغاء الشرط: مطاردة علاوة لا تمنع BUY إن باقي البوابات اكتملت."""
        import cheap_options_screener_v3 as s
        self.assertFalse(s.PREMIUM_CHASE_BLOCKS_BUY)
        os.environ["IGNORE_EXEC_WINDOW"] = "1"
        r = {
            "Ticker": "AMZN",
            "price_num": 249.50,
            "strike": 247.5,
            "iv": 0.45,
            "premium": 1.20,
            "oi": 5000,
            "opt_vol": 2000,
            "spread_pct": 0.04,
            "dte_num": 3,
            "direction": "PUT",
            "Score": 24,
            "spy_regime": "BEAR",
            "RVOL": 2.0,
            "atr_pct": 3.0,
            "is_0dte": False,
            "opt_bid": 1.15,
            "opt_ask": 1.25,
            "synthetic_quote": False,
            "gap_pct": -2.0,
            "opt_change_pct": 200.0,  # كان يسدّ BUY سابقاً
            "prem_prev": 0.35,
        }
        tech = {
            "atr14": 2.0,
            "trend": "BEARISH 🔴",
            "above_ema20": False,
            "above_ema50": False,
            "above_vwap": False,
            "rsi": 35,
            "support1": 250.0,
            "support2": 245.0,
            "resist1": 255.0,
            "yesterday_high": 256.0,
            "yesterday_low": 248.0,
            "session_high": 255.0,
            "session_low": 249.0,
        }
        plan = s.compute_trade_plan(r, tech)
        self.assertTrue(plan.get("premium_chased"))
        self.assertNotIn("مطاردة علاوة", plan.get("rec_note") or "")
        # إن اكتمل الكسر وباقي الشروط: لا يُرفض بسبب العلاوة
        if plan.get("break_confirmed") and plan.get("recommendation") != "BUY":
            self.assertNotIn("مطاردة علاوة", plan.get("rec_note") or "")


class TestPremMaxBlocksBuy(unittest.TestCase):
    """سقف العلاوة شرط BUY — لا تسريب مثل SPY $6.89 فوق $5."""

    def tearDown(self):
        os.environ.pop("IGNORE_EXEC_WINDOW", None)

    def test_spy_premium_above_ceiling_no_buy(self):
        import cheap_options_screener_v3 as s
        os.environ["IGNORE_EXEC_WINDOW"] = "1"
        # يطابق حالة تيليجرام 2026-10-23: SPY PUT 760 · prem 6.89 · كسر تحت Entry
        r = {
            "Ticker": "SPY",
            "price_num": 760.35,
            "strike": 760.0,
            "iv": 0.16,
            "premium": 6.89,
            "oi": 78081,
            "opt_vol": 5000,
            "spread_pct": 0.0058,
            "dte_num": 7,
            "direction": "PUT",
            "Score": 16,
            "spy_regime": "BEAR",
            "RVOL": 1.8,
            "atr_pct": 1.0,
            "is_0dte": False,
            "opt_bid": 6.87,
            "opt_ask": 6.91,
            "synthetic_quote": False,
            "gap_pct": -0.4,
        }
        tech = {
            "atr14": 7.0,
            "trend": "BEARISH 🔴",
            "above_ema20": False,
            "above_ema50": False,
            "above_vwap": False,
            "rsi": 40,
            "support1": 761.17,
            "support2": 755.0,
            "resist1": 768.0,
            "yesterday_high": 770.0,
            "yesterday_low": 758.0,
            "session_high": 765.0,
            "session_low": 759.5,
        }
        plan = s.compute_trade_plan(r, tech)
        self.assertEqual(s.profile_limit("SPY", "prem_max", s.TARGET_PREM_MAX), 5.0)
        self.assertNotEqual(plan["recommendation"], "BUY", plan.get("rec_note"))
        self.assertIn("فوق السقف", plan.get("rec_note") or "")

    def test_mega_premium_above_3_no_buy(self):
        import cheap_options_screener_v3 as s
        os.environ["IGNORE_EXEC_WINDOW"] = "1"
        r = {
            "Ticker": "AMZN",
            "price_num": 249.50,
            "strike": 247.5,
            "iv": 0.45,
            "premium": 4.50,  # فوق سقف الكبار $3
            "oi": 5000,
            "opt_vol": 2000,
            "spread_pct": 0.04,
            "dte_num": 3,
            "direction": "PUT",
            "Score": 24,
            "spy_regime": "BEAR",
            "RVOL": 2.0,
            "atr_pct": 3.0,
            "is_0dte": False,
            "opt_bid": 4.40,
            "opt_ask": 4.60,
            "synthetic_quote": False,
            "gap_pct": -2.0,
        }
        tech = {
            "atr14": 2.0,
            "trend": "BEARISH 🔴",
            "above_ema20": False,
            "above_ema50": False,
            "above_vwap": False,
            "rsi": 35,
            "support1": 250.0,
            "support2": 245.0,
            "resist1": 255.0,
            "yesterday_high": 256.0,
            "yesterday_low": 248.0,
            "session_high": 255.0,
            "session_low": 249.0,
        }
        plan = s.compute_trade_plan(r, tech)
        self.assertEqual(s.profile_limit("AMZN", "prem_max", s.TARGET_PREM_MAX), 3.0)
        self.assertNotEqual(plan["recommendation"], "BUY")
        self.assertIn("فوق السقف", plan.get("rec_note") or "")


class TestGapDirectionScore(unittest.TestCase):
    def test_down_gap_helps_put_hurts_call(self):
        put_row = {"direction": "PUT", "gap_pct": -9.0, "today_vol": 0, "avg_vol": 0}
        call_row = {"direction": "CALL", "gap_pct": -9.0, "today_vol": 0, "avg_vol": 0}
        put_score, put_notes = score_stock(put_row)
        call_score, call_notes = score_stock(call_row)
        self.assertGreater(put_score, call_score)
        self.assertTrue(any("PUT" in n for n in put_notes))
        self.assertTrue(any("ضد CALL" in n for n in call_notes))

    def test_gap_conflict_helper(self):
        self.assertTrue(gap_direction_conflict(-3.5, True))
        self.assertFalse(gap_direction_conflict(-1.0, True))
        self.assertTrue(gap_direction_conflict(3.5, False))
        self.assertFalse(gap_direction_conflict(1.0, False))


class TestTelegramGapFilter(unittest.TestCase):
    def test_call_with_down_gap_is_conflict(self):
        row = {"direction": "CALL", "gap_pct": -9.0, "trend": "BEARISH 🔴"}
        self.assertTrue(wait_hot_direction_conflict(row))
        self.assertEqual(telegram_skip_reason(row, kind="WAIT_HOT"), "gap_trend")

    def test_put_with_up_gap_is_conflict(self):
        row = {"direction": "PUT", "gap_pct": 4.0, "trend": "BULLISH 🟢"}
        self.assertTrue(wait_hot_direction_conflict(row))

    def test_aligned_hot_not_skipped_for_gap(self):
        row = {
            "direction": "PUT", "gap_pct": -2.0, "trend": "BEARISH 🔴",
            "tp1_rr_live": 1.5, "rec_note": "راقب",
        }
        self.assertFalse(wait_hot_direction_conflict(row))
        self.assertEqual(telegram_skip_reason(row, kind="WAIT_HOT"), "")


if __name__ == "__main__":
    unittest.main()
