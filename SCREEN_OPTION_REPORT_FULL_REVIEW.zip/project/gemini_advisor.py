"""
gemini_advisor.py
-----------------
مستشار Gemini بعد قواعد السكرينر فقط.
لا يغيّر BUY/WAIT/AVOID — يضيف ملاحظة تحليلية قصيرة (عربي).

المتغير: GEMINI_API_KEY من Google AI Studio
اختياري: GEMINI_MODEL (افتراضي gemini-3.1-flash-lite)
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Mapping, Optional

import pandas as pd
import requests

RESULTS_FILE = "options_v3_results.csv"
# 2.0/1.5 Flash أُغلقت mid-2026 — الافتراضي موديلات حالية قصيرة وسريعة
DEFAULT_MODEL = (
    os.environ.get("GEMINI_MODEL", "gemini-3.1-flash-lite").strip()
    or "gemini-3.1-flash-lite"
)
MODEL_FALLBACKS = [
    DEFAULT_MODEL,
    "gemini-3.1-flash-lite",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.5-flash",
]
# unique preserve order
_seen = set()
MODEL_FALLBACKS = [m for m in MODEL_FALLBACKS if m and not (m in _seen or _seen.add(m))]
API_BASE = "https://generativelanguage.googleapis.com/v1beta"


def get_api_key() -> str:
    return (os.environ.get("GEMINI_API_KEY")
            or os.environ.get("GOOGLE_API_KEY")
            or "").strip()


def _num(val: Any, default: float = 0.0) -> float:
    try:
        if val is None or val == "":
            return default
        return float(str(val).replace("$", "").replace(",", ""))
    except (TypeError, ValueError):
        return default


def _row_payload(row: Mapping[str, Any]) -> dict:
    return {
        "ticker": str(row.get("Ticker") or row.get("ticker") or "?"),
        "recommendation": str(row.get("recommendation") or "AVOID"),
        "direction": str(row.get("direction") or ""),
        "confidence": _num(row.get("confidence")),
        "score": _num(row.get("Score") or row.get("score")),
        "price": _num(row.get("Price") or row.get("price_num")),
        "entry": _num(row.get("entry_stock")),
        "stop": _num(row.get("stop_stock")),
        "tp1": _num(row.get("tp1_stock")),
        "tp2": _num(row.get("tp2_stock")),
        "tp3": _num(row.get("tp3_stock")),
        "tp1_rr": _num(row.get("tp1_rr")),
        "tp1_rr_live": _num(row.get("tp1_rr_live")),
        "entry_chased": str(row.get("entry_chased") or ""),
        "premium": _num(row.get("premium")),
        "strike": _num(row.get("strike")),
        "expiry": str(row.get("expiry") or ""),
        "dte": _num(row.get("dte_num")),
        "spread_pct": _num(row.get("spread_pct")),
        "iv": _num(row.get("iv")),
        "oi": _num(row.get("oi")),
        "spy_regime": str(row.get("spy_regime") or ""),
        "rec_note": str(row.get("rec_note") or ""),
        "entry_note": str(row.get("entry_note") or ""),
        "earnings": str(row.get("earnings") or ""),
        "fh_pm_note": str(row.get("fh_pm_note") or ""),
    }


def _build_prompt(payload: dict) -> str:
    return f"""أنت مستشار تعليمي لسكربت خيارات أمريكية. القواعد الحاسوبية قررت مسبقاً التوصية ولا يجوز تغييرها.

التوصية النهائية الثابتة: {payload['recommendation']}
البيانات:
{json.dumps(payload, ensure_ascii=False, indent=2)}

اكتب بالعربية الفصحى المبسطة فقط:
1) سطر واحد: تقييم المخاطر (منخفض/متوسط/مرتفع) مع سبب مختصر.
2) سطر واحد: نقطة مراقبة مهمة قبل التنفيذ (مطاردة Entry، أرباح، سبريد، R:R حي، اتجاه SPY...).
3) سطر واحد: تذكير أن هذا تعليمي وليس نصيحة استثمارية.

ممنوع:
- تغيير التوصية أو اقتراح BUY إذا كانت WAIT/AVOID
- أرقام أسعار جديدة من عندك
- وعود ربح

الحد الأقصى: 3 أسطر قصيرة جداً."""


def _extract_text(data: dict) -> str:
    cands = data.get("candidates") or []
    if not cands:
        # غالباً safety / block
        fb = data.get("promptFeedback") or {}
        print(f"  ⚠ Gemini no candidates: {fb or list(data.keys())[:6]}")
        return ""
    parts = (cands[0].get("content") or {}).get("parts") or []
    chunks = []
    for p in parts:
        t = p.get("text")
        if t:
            chunks.append(str(t).strip())
    return " ".join(chunks).strip()


def advise_row(row: Mapping[str, Any], api_key: Optional[str] = None,
               model: Optional[str] = None, timeout: int = 25) -> str:
    """يرجع نص المستشار أو سلسلة فارغة عند الفشل/غياب المفتاح."""
    key = (api_key or get_api_key()).strip()
    if not key:
        return ""

    models = [model] if model else list(MODEL_FALLBACKS)
    payload = _row_payload(row)
    # maxOutputTokens مرتفع: موديلات Thinking (مثل 2.5/3.5 Flash) تستهلك الميزانية داخلياً
    # لو الحد صغير يرجع candidates بدون نص ظاهر
    body = {
        "contents": [{"parts": [{"text": _build_prompt(payload)}]}],
        "generationConfig": {
            "temperature": 0.3,
            "maxOutputTokens": 1024,
        },
    }
    last_err = ""
    for model_id in models:
        if not model_id:
            continue
        url = f"{API_BASE}/models/{model_id}:generateContent"
        # جرّب بدون thinking أولاً (إن دعمه الموديل)، ثم بدون الحقل
        payloads = [
            {**body, "generationConfig": {
                **body["generationConfig"],
                "thinkingConfig": {"thinkingBudget": 0},
            }},
            body,
        ]
        for req_body in payloads:
            try:
                resp = requests.post(
                    url,
                    params={"key": key},
                    headers={"Content-Type": "application/json"},
                    json=req_body,
                    timeout=timeout,
                )
                if resp.status_code >= 400:
                    # thinkingConfig غير مدعوم → جرّب الطلب البسيط
                    last_err = f"{model_id} HTTP {resp.status_code}: {resp.text[:180]}"
                    if resp.status_code in (400, 404) and "thinkingConfig" in str(req_body):
                        continue
                    print(f"  ⚠ Gemini {last_err}")
                    break
                data = resp.json()
                text = _extract_text(data)
                text = " ".join(text.split())
                if len(text) > 500:
                    text = text[:497] + "…"
                if text:
                    print(f"  ✓ model={model_id}")
                    return text
                finish = ((data.get("candidates") or [{}])[0]).get("finishReason")
                last_err = f"{model_id} empty text (finish={finish})"
                print(f"  ⚠ Gemini {last_err}")
                break
            except Exception as e:
                last_err = f"{model_id} {e}"
                print(f"  ⚠ Gemini error: {last_err}")
                break
    if last_err:
        print(f"  ⚠ Gemini failed all models: {last_err}")
    return ""


def enrich_dataframe(df: pd.DataFrame, only_recs=("BUY", "WAIT"),
                     sleep_s: float = 0.4) -> pd.DataFrame:
    """يضيف عمود gemini_note بدون تعديل recommendation."""
    if df is None or df.empty:
        return df
    out = df.copy()
    # CSV الفاضي يخليه pandas float64 (NaN) — لازم object قبل كتابة نص
    if "gemini_note" not in out.columns:
        out["gemini_note"] = pd.Series([""] * len(out), dtype="object")
    else:
        out["gemini_note"] = out["gemini_note"].astype("object")
        out["gemini_note"] = out["gemini_note"].where(
            out["gemini_note"].notna(), ""
        ).astype(str)
        out.loc[out["gemini_note"].str.lower() == "nan", "gemini_note"] = ""

    if not get_api_key():
        print("Gemini: لا يوجد GEMINI_API_KEY — تخطي المستشار")
        return out

    mask = out["recommendation"].isin(list(only_recs))
    idxs = list(out.index[mask])
    print(f"Gemini advisor: {len(idxs)} صف ({', '.join(only_recs)})")
    for i, idx in enumerate(idxs, 1):
        row = out.loc[idx]
        note = advise_row(row)
        out.at[idx, "gemini_note"] = note if note else ""
        ticker = row.get("Ticker", "?")
        print(f"  [{i}/{len(idxs)}] {ticker}: {'✓' if note else '—'}")
        if sleep_s > 0 and i < len(idxs):
            time.sleep(sleep_s)
    return out


def enrich_results_csv(path: str = RESULTS_FILE) -> bool:
    if not os.path.exists(path):
        print(f"⚠️  {path} غير موجود")
        return False
    df = pd.read_csv(path)
    if not get_api_key():
        print("Gemini: لا يوجد GEMINI_API_KEY — تخطي المستشار")
        return True
    enriched = enrich_dataframe(df)
    # أجبر العمود نصاً حتى لو فاضي — وإلا pandas يحفظه float64/NaN
    enriched["gemini_note"] = (
        enriched["gemini_note"].fillna("").astype(str).replace({"nan": "", "None": ""})
    )
    enriched.to_csv(path, index=False)
    n = enriched["gemini_note"].fillna("").astype(str).str.strip()
    n = n[n.ne("") & n.str.lower().ne("nan")].shape[0]
    print(f"✓ حُفظ {path} — ملاحظات Gemini: {n}")
    if n == 0:
        print("⚠️  لم تُكتب أي ملاحظة — راجع المفتاح/الموديل/الحصة المجانية")
    return True


def main():
    # المستشار اختياري — لا يوقف المسح أو تيليجرام عند الفشل
    try:
        enrich_results_csv(RESULTS_FILE)
    except Exception as e:
        print(f"⚠️  Gemini advisor crashed (non-fatal): {e}")
    raise SystemExit(0)


if __name__ == "__main__":
    main()
