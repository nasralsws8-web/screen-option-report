# Review package — SCREEN_OPTION_REPORT_FULL_REVIEW

This archive is for **independent read-only analysis** (e.g. ChatGPT).

## Contents
- `PROJECT_OVERVIEW.md` — product, gates, data flow, APIs, limits
- `PROJECT_STRUCTURE.txt` — directory tree
- `.env.example` — secret **names** only
- `project/` — full source + CSV data snapshots + tests + workflows (no `.git`, no caches, no real `.env`)

## Rules
- Do not treat suggestions as live gate changes.
- Cursor remains the product owner for code and BUY gates (`project/.cursor/rules/partners.mdc`).
- No passwords/API keys are included; CI references `${{ secrets.* }}` placeholders only.

## Suggested reading order
1. PROJECT_OVERVIEW.md
2. project/GATE_CHANGE_PROPOSALS.md
3. project/.cursor/rules/partners.mdc
4. project/cheap_options_screener_v3.py (profiles + `compute_trade_plan`)
5. project/tests/test_gates.py
6. project/dashboard.html + outcomes.csv sample rows
