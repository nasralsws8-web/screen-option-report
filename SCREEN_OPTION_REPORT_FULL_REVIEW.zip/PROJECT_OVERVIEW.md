# PROJECT OVERVIEW — screen-option-report

**Package purpose:** Read-only technical review for an external analyst (e.g. ChatGPT).  
**Product owner / implementer:** Cursor (see `.cursor/rules/partners.mdc`). External AI must not control or change production gates.  
**Repo:** https://github.com/nasralsws8-web/screen-option-report  
**Snapshot branch tip (at packaging):** `main` (verify commit inside `project/` via file dates; `.git` intentionally omitted).

---

## 1. Idea and primary goal

Educational / personal **US equity options screener** that:

1. Scans liquid optionable names (Finviz + manual mega-cap/SPY list).
2. Picks short-dated (prefer Friday) CALL/PUT contracts in a **premium band**.
3. Builds a trade plan (Entry / Stop / TP1–3) from structure + ATR.
4. Emits **BUY / WAIT / WAIT_HOT / AVOID / SKIP** with Arabic notes.
5. Surfaces cards on a static **dashboard** (GitHub Pages) and optional **Telegram**.
6. Tracks outcomes in **`outcomes.csv`** after the close (judgment = closed BUY reliability).

Goal of the “gates”: catch **cheap, break-confirmed** setups without chasing extended moves or expensive ATM premiums—especially on mega-caps (≤ $3) and SPY (≤ $5 after fix).

---

## 2. Current features

| Area | What it does |
|------|----------------|
| Full scan | `cheap_options_screener_v3.py` — Finviz universe + `manual_tickers.txt` + priority SPY/mega pins |
| Trade plan | Entry break (Jalwe-style), stop, TP ladder, live R:R, confidence, Black–Scholes Greeks/scenarios |
| BUY gates | Exec window (≥15m after open ET), premium band, liquidity, SPY align (mega exempt), no 0DTE BUY, no chase >0.8% stock, no BUY after session TP1, gap conflict, premium quality vs BS |
| WAIT grading | `setup_pct` / `wait_tier` (HOT/FIRE…) for monitoring; **not** auto-buy |
| Dashboard | `dashboard.html` loads CSVs from repo/Pages — live cards, rejected lane, history/study |
| Telegram | `telegram_notify.py` — BUY + selected WAIT_HOT; dedupe via `telegram_sent.json` |
| Outcomes | `outcome_tracker.py` — entry hit, stop/tp1, option PnL, data quality |
| Price refresh | `price_update.py` + workflow |
| Pre-breakout stocks | `stock_prebreakout*.py` — separate equity watchlist CSV |
| Advisor (optional) | `gemini_advisor.py` — notes only if `GEMINI_API_KEY` set |
| Premarket enrich | `finnhub_premarket.py` if `FINNHUB_API_KEY` |
| EOD options | `theta_eod.py` — Theta terminal when available; Yahoo fallback |
| Session notes | `session_note.py` + `sessions/` Obsidian-style memory from outcomes (does not decide gates) |
| CI schedules | `.github/workflows/*` — screener, price update, EOD, Pages deploy, prebreakout |
| Tests | `tests/test_gates.py` (primary gate suite), theta/prebreakout/session/push helpers |

---

## 3. Tech stack

- **Language:** Python 3.11 (Actions), plain JS in single-page `dashboard.html`
- **Libs:** `yfinance`, `finvizfinance`, `pandas`, `numpy`, `scipy`, `requests`, `curl_cffi`, `Pillow` (see `requirements.txt`)
- **Storage:** CSV/JSON files in git (no SQL DB, no migrations)
- **Hosting UI:** GitHub Pages (`deploy-pages.yml`)
- **Automation:** GitHub Actions cron
- **Notify:** Telegram Bot API
- **Optional APIs:** Finnhub, Google Gemini, Theta Data terminal

No Node/`package.json` frontend build — dashboard is static HTML.

---

## 4. Project structure (summary)

See **`PROJECT_STRUCTURE.txt`** for the full tree.

```
project/
  cheap_options_screener_v3.py   # engine + gates
  dashboard.html                 # UI
  outcome_tracker.py             # post-trade path
  telegram_notify.py
  outcomes.csv / options_v3_results.csv / options_rejected_log.csv
  GATE_CHANGE_PROPOSALS.md       # gate change log
  .cursor/rules/partners.mdc     # ownership / who may edit what
  .github/workflows/             # schedules
  tests/                         # unit tests
  sessions/                      # daily notes (memory, non-deciding)
```

---

## 5. Data flow

```
Finviz / manual_tickers / PRIORITY_TICKERS
        ↓
Yahoo (chains, OHLC, quotes) [+ Finnhub PM optional] [+ Theta EOD optional]
        ↓
cheap_options_screener_v3.py
  · pick strike/expiry by profile (SPY ATM~0.5% · mega cheap OTM)
  · compute_trade_plan → recommendation
  · filter save → options_v3_results.csv
  · rejects → options_rejected_log.csv
        ↓
outcome_tracker.py → outcomes.csv (history + PnL path)
        ↓
gemini_advisor.py (optional notes on rows)
        ↓
telegram_notify.py → Telegram + telegram_sent.json flags on outcomes
        ↓
git commit CSVs (Actions) → GitHub → dashboard.html fetch
```

**User execution surface:** live dashboard cards after Saudi ~4:45 (exec window). User does not edit code/ratios.

---

## 6. Decision mechanism (algorithms / gates)

### 6.1 Profiles

- **Default:** premium **$1–$3**
- **Mega-caps** (AAPL, AMZN, TSLA, NVDA, MSFT, GOOGL, GOOG, META, AMD): **$1–$3**, target ~$1.50, OTM allowed ~4%, **SPY-alignment exempt**
- **SPY:** premium **$1–$5**, target ~$2.50, prefer near ATM (`max_strike_dist=0.005`)

### 6.2 Entry

- CALL: break nearest resistance / session high; hold above  
- PUT: break nearest support / session low; hold below  
- BUY requires `break_confirmed` (price through Entry) and **not** stock chase > **0.8%** past Entry

### 6.3 BUY conjunction (high level)

All roughly required (see `compute_trade_plan`):

- `confidence ≥ 55`, live R:R ≥ 1.3  
- liquid OI/spread  
- **`prem_min ≤ premium ≤ prem_max`** (ceiling enforced in BUY as of 2026-10-23)  
- premium quality OK (market mid vs BS)  
- SPY regime align (unless mega exempt)  
- not inverse-ETF auto-BUY  
- not 0DTE  
- not TP1 already touched in session  
- not opposing gap conflict  
- inside exec window  
- trend OK or high-conf MIXED  

`PREMIUM_CHASE_BLOCKS_BUY = False` (2026-10-22): Yahoo % spikes measured in CSV only, do not block BUY.

### 6.4 WAIT_HOT

Near-complete setups for **manual watch**; Telegram may alert. Must **not** be mixed into BUY win-rate stats without labeling.

### 6.5 Outcomes judgment

Reliable performance judgment = **closed BUY** rows in `outcomes.csv` after EOD enrichment—not WAIT_HOT spam.

---

## 7. External services / APIs

| Service | Role | Credentials |
|---------|------|-------------|
| Yahoo Finance (yfinance) | Chains, history, quotes | None (scraping; fragile) |
| Finviz | Screener universe | None |
| Finnhub | Premarket confirm | `FINNHUB_API_KEY` |
| Telegram | Alerts | `TELEGRAM_TOKEN`, `TELEGRAM_CHAT_ID` |
| Gemini | Optional Arabic notes | `GEMINI_API_KEY`, optional `GEMINI_MODEL` |
| Theta | EOD option marks | `THETA_*` / local terminal |
| GitHub Actions secrets | Injected only in CI | never stored in repo files |

This review ZIP includes **`.env.example`** only (no real secrets).

---

## 8. Completed vs in progress / deferred

**Completed (as of late Oct 2026 packaging):**

- Gate set A–G (break entry, TP1 block, gap, SPY strike distance, first-hour cron */5, …)  
- Mega-cap SPY-exempt + cheap OTM ≤$3 + pin list  
- Cancel premium-chase as BUY blocker; keep measurement  
- Enforce `prem_max` inside BUY gate (SPY ≤$5 / mega ≤$3)  
- Dashboard + Telegram + outcomes pipeline + gate unit tests  

**Deferred / open:**

- SPX support (proposal H)  
- Possible SPY strike policy revisit (ATM forces expensive premiums vs cheap OTM examples ~$1.30)  
- Option-level MFE not stored (only stock MFE/MAE)  
- Yahoo quote quality / estimate bids remain a failure mode  

---

## 9. Known issues and constraints

1. **Yahoo dependency** — missing bid/ask, wild `opt_change_pct`, IV gaps → WAIT or bad premiums.  
2. **SPY ATM preference** can select expensive contracts near spot; ceiling now blocks BUY above `$5`, but may yield fewer SPY BUYs.  
3. **WAIT_HOT volume** can look like signals; executing all of them historically underperformed vs BUY-only discipline.  
4. **No traditional DB** — concurrency controlled by Actions `concurrency: repo-csv-writes`.  
5. **Dashboard ≠ localhost** — live truth is GitHub `main` / Pages after Actions push.  
6. **Governance:** only Cursor should change `dashboard.html`, BUY gates, KPI/`rec_kind` rules (see `partners.mdc`).  
7. **Educational use** — not a broker; user executes manually from cards.

---

## 10. How to review without running

1. Read `GATE_CHANGE_PROPOSALS.md` + `.cursor/rules/partners.mdc`.  
2. Read `compute_trade_plan` / profiles / `row_passes_save_filters` in `cheap_options_screener_v3.py`.  
3. Skim `tests/test_gates.py` for intended gate behavior.  
4. Sample `outcomes.csv` + `telegram_sent.json` for week of 2026-10-19..23.  
5. Open `dashboard.html` logic (fetch URLs for CSVs) as the user-facing surface.  
6. Do **not** treat this ZIP as authority to change production; propose only; Cursor implements.

---

## 11. CSV “schema” (file-backed store)

No SQL migrations. Primary tables:

- **`options_v3_results.csv`** — latest accepted/watch scan rows for dashboard cards.  
- **`options_rejected_log.csv`** — scanned but not fully accepted (SKIP lane).  
- **`outcomes.csv`** — longitudinal recommendations + path metrics (`status`, `option_pnl_pct`, `mfe_pct`, `telegram_sent`, …).  
- **`telegram_sent.json`** — dedupe keys `date|TICKER|SIDE|strike|expiry` and `WAIT_HOT|...`.  
- **`stock_prebreakout*.csv`** — equity pre-breakout side scan.

Sample env names: see `.env.example` at package root.
